import csv

# Einlesen einer CSV-Datei mit csv.reader
with open("Erwerbstaetige1.csv", mode='r', newline='') as file:
    csv_reader = csv.reader(file)
    data = list(csv_reader)

#print(data)


# Einlesen einer CSV-Datei mit csv.DictReader
with open('Erwerbstaetige1.csv', mode='r', newline='') as file:
    csv_dict_reader = csv.DictReader(file, delimiter=";")
    data = list(csv_dict_reader)

print(data)



